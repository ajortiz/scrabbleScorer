package scrabble;

public interface Dictionary
{
	public boolean contains(String string);
}
